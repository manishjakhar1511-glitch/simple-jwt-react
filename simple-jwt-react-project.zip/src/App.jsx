import React, { useEffect, useState } from "react";
import Login from "./components/Login";
import Dashboard from "./components/Dashboard";

const TOKEN_KEY = "jwt_token";

function encode(value) {
  return btoa(JSON.stringify(value));
}

// Simulated JWT: HEADER.PAYLOAD.SIGNATURE
function generateToken(userId, role) {
  const header = {
    alg: "HS256",
    typ: "JWT"
  };

  const payload = {
    userId,
    role,
    iat: Date.now()
  };

  const signature = btoa("simulated-signature");

  return `${encode(header)}.${encode(payload)}.${signature}`;
}

function decodeToken(token) {
  try {
    const parts = token.split(".");
    if (parts.length !== 3) return null;
    return JSON.parse(atob(parts[1]));
  } catch {
    return null;
  }
}

export default function App() {
  const [token, setToken] = useState(() => localStorage.getItem(TOKEN_KEY));
  const [user, setUser] = useState(null);

  useEffect(() => {
    if (token) {
      setUser(decodeToken(token));
    } else {
      setUser(null);
    }
  }, [token]);

  const handleLogin = (username, password) => {
    // Demo credentials for this practical
    if (username === "admin" && password === "1234") {
      const newToken = generateToken("101", "Admin");
      localStorage.setItem(TOKEN_KEY, newToken);
      setToken(newToken);
      return { success: true };
    }

    if (username === "student" && password === "1234") {
      const newToken = generateToken("102", "Student");
      localStorage.setItem(TOKEN_KEY, newToken);
      setToken(newToken);
      return { success: true };
    }

    return {
      success: false,
      message: "Invalid username or password."
    };
  };

  const handleLogout = () => {
    localStorage.removeItem(TOKEN_KEY);
    setToken(null);
    setUser(null);
  };

  if (!token || !user) {
    return <Login onLogin={handleLogin} />;
  }

  return <Dashboard user={user} token={token} onLogout={handleLogout} />;
}