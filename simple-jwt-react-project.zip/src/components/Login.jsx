import React, { useState } from "react";

export default function Login({ onLogin }) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  const handleSubmit = (event) => {
    event.preventDefault();
    setError("");

    if (!username || !password) {
      setError("Please enter username and password.");
      return;
    }

    const result = onLogin(username, password);

    if (!result.success) {
      setError(result.message);
    }
  };

  return (
    <main className="page">
      <section className="card login-card">
        <h1>JWT Authentication</h1>
        <p className="subtitle">Simple React Login System</p>

        <form onSubmit={handleSubmit}>
          <label>Username</label>
          <input
            type="text"
            placeholder="Enter username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
          />

          <label>Password</label>
          <input
            type="password"
            placeholder="Enter password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />

          {error && <p className="error">{error}</p>}

          <button type="submit">Login</button>
        </form>

        <div className="demo-box">
          <strong>Demo credentials</strong>
          <p>Admin: admin / 1234</p>
          <p>Student: student / 1234</p>
        </div>
      </section>
    </main>
  );
}