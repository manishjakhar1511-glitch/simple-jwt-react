import React from "react";

export default function Dashboard({ user, token, onLogout }) {
  return (
    <main className="page">
      <section className="card dashboard-card">
        <div className="top-row">
          <div>
            <p className="badge">Authenticated</p>
            <h1>Protected Dashboard</h1>
          </div>
          <button className="logout" onClick={onLogout}>Logout</button>
        </div>

        <div className="info-grid">
          <div className="info">
            <span>User ID</span>
            <strong>{user.userId}</strong>
          </div>

          <div className="info">
            <span>Role</span>
            <strong>{user.role}</strong>
          </div>
        </div>

        <div className="token-box">
          <h3>Stored Simulated JWT</h3>
          <code>{token}</code>
        </div>

        <p className="success">
          You can see this Dashboard because a token is stored and the user is
          authenticated.
        </p>
      </section>
    </main>
  );
}