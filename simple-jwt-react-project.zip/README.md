# Simple JWT Authentication - React Practical

## Aim
Create a simple React Login System demonstrating authentication, simulated JWT generation, token storage, role display, protected UI, and logout.

## Features
- Username and password fields
- Login button
- Simulated JWT generation
- JWT payload contains `userId` and `role`
- Token stored in `localStorage`
- Protected Dashboard
- User role displayed after login
- Logout removes the token

## Demo Credentials

### Admin
- Username: `admin`
- Password: `1234`
- Role: `Admin`

### Student
- Username: `student`
- Password: `1234`
- Role: `Student`

## How to Run

1. Install Node.js.
2. Open this project folder in a terminal.
3. Run:

```bash
npm install
npm run dev
```

4. Open the local URL shown by Vite, usually:
   `http://localhost:5173`

## Project Structure

```text
simple-jwt-react-project/
├── public/
├── src/
│   ├── components/
│   │   ├── Login.jsx
│   │   └── Dashboard.jsx
│   ├── App.jsx
│   ├── App.css
│   └── main.jsx
├── index.html
├── package.json
└── README.md
```

## Workflow

User → Login Form → Credential Check → Generate Simulated JWT → Store Token → Read Token → Protected Dashboard → Logout → Remove Token

## Important Note

This project intentionally uses a simulated JWT for educational purposes. It is not production authentication. In a real system, credentials should be verified by a backend and the JWT should be securely signed by the server.
